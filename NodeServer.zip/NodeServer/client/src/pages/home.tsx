import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Key, 
  Plus, 
  Copy, 
  Shield, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  XCircle
} from "lucide-react";

interface KeyData {
  id: string;
  key: string;
  createdAt: string;
  expiresAt: string;
  timeRemaining?: {
    total: number;
    hours: number;
    minutes: number;
    formatted: string;
  };
}

interface ValidationResult {
  valid: boolean;
  status: 'valid' | 'invalid' | 'expired';
  message: string;
  key?: KeyData;
  timeRemaining?: {
    total: number;
    hours: number;
    minutes: number;
    formatted: string;
  };
}

export default function Home() {
  const [validationKey, setValidationKey] = useState("");
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);
  const { toast } = useToast();

  // Fetch all active keys
  const { data: activeKeys = [], isLoading: keysLoading } = useQuery<KeyData[]>({
    queryKey: ["/api/keys"],
    refetchInterval: 60000, // Refetch every minute to update timers
  });

  // Generate new key mutation
  const generateKeyMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/generate");
      return response.json();
    },
    onSuccess: async (newKey) => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
      
      // Automaticamente preenche o campo de validação com a nova chave
      setValidationKey(newKey.key);
      
      // Automaticamente verifica a chave recém-gerada
      await validateGeneratedKey(newKey.key);
      
      toast({
        title: "Chave gerada e verificada!",
        description: "Nova chave criada e validada automaticamente.",
      });
    },
    onError: () => {
      toast({
        title: "Erro ao gerar chave",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    },
  });

  // Função para validar chave recém-gerada automaticamente
  const validateGeneratedKey = async (keyToValidate: string) => {
    try {
      const url = `/api/validate/${encodeURIComponent(keyToValidate)}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result: ValidationResult = await response.json();
      setValidationResult(result);
      
    } catch (error) {
      console.error('Auto-validation error:', error);
      setValidationResult(null);
    }
  };

  // Validate key function
  const validateKey = async () => {
    const keyToValidate = validationKey.trim();
    
    if (!keyToValidate) {
      toast({
        title: "Chave inválida",
        description: "Por favor, insira uma chave para validar.",
        variant: "destructive",
      });
      return;
    }

    console.log('Validating key:', keyToValidate);

    try {
      const url = `/api/validate/${encodeURIComponent(keyToValidate)}`;
      console.log('Request URL:', url);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      console.log('Response status:', response.status);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result: ValidationResult = await response.json();
      console.log('Validation result:', result);
      
      setValidationResult(result);
      
      if (result.valid) {
        toast({
          title: "Chave válida!",
          description: `Esta chave expira em ${result.timeRemaining?.formatted}`,
        });
      } else {
        toast({
          title: "Chave inválida",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Validation error:', error);
      setValidationResult(null);
      toast({
        title: "Erro na validação",
        description: "Não foi possível validar a chave. Verifique se ela está correta e tente novamente.",
        variant: "destructive",
      });
    }
  };

  // Copy to clipboard function
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copiado!",
        description: "Chave copiada para a área de transferência.",
      });
    } catch (error) {
      toast({
        title: "Erro ao copiar",
        description: "Não foi possível copiar a chave.",
        variant: "destructive",
      });
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  // Get status info for a key
  const getKeyStatus = (key: KeyData) => {
    if (!key.timeRemaining) return { status: 'expired', color: 'bg-gray-400' };
    
    const hoursRemaining = key.timeRemaining.hours;
    if (hoursRemaining > 12) return { status: 'active', color: 'bg-success' };
    if (hoursRemaining > 4) return { status: 'warning', color: 'bg-warning' };
    return { status: 'expiring', color: 'bg-error' };
  };

  const latestKey = activeKeys[0];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center space-x-3">
            <div className="bg-primary p-2 rounded-lg">
              <Key className="text-white text-xl" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Key Generator</h1>
              <p className="text-sm text-gray-600">Gerador de chaves únicas com expiração automática</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Main Action Card */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="bg-blue-50 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Plus className="text-primary text-2xl" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Gerar Nova Chave</h2>
              <p className="text-gray-600">Clique no botão abaixo para gerar uma chave única que expira em 24 horas</p>
            </div>

            <div className="flex justify-center">
              <Button 
                onClick={() => generateKeyMutation.mutate()}
                disabled={generateKeyMutation.isPending}
                className="bg-primary hover:bg-blue-700 text-white px-8 py-4 text-lg transform hover:scale-105 hover:shadow-lg"
                data-testid="button-generate-key"
              >
                {generateKeyMutation.isPending ? (
                  <div className="flex items-center space-x-3">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Gerando...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-3">
                    <Plus className="w-5 h-5" />
                    <span>Gerar Key</span>
                  </div>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Generated Key Display */}
        {latestKey && (
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-gray-900">Chave Gerada</h3>
                <Badge className="bg-success text-white">
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Ativa
                </Badge>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between">
                  <code className="font-mono text-lg text-gray-900 bg-white px-3 py-2 rounded border flex-1 mr-3">
                    {latestKey.key}
                  </code>
                  <Button 
                    variant="outline"
                    onClick={() => copyToClipboard(latestKey.key)}
                    data-testid="button-copy-key"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="text-gray-600 mb-1">Gerada em</div>
                  <div className="font-semibold text-gray-900" data-testid="text-created-at">
                    {formatDate(latestKey.createdAt)}
                  </div>
                </div>
                <div className="bg-orange-50 p-3 rounded-lg">
                  <div className="text-gray-600 mb-1">Expira em</div>
                  <div className="font-semibold text-warning" data-testid="text-expires-at">
                    {formatDate(latestKey.expiresAt)}
                  </div>
                </div>
                <div className="bg-green-50 p-3 rounded-lg">
                  <div className="text-gray-600 mb-1">Tempo restante</div>
                  <div className="font-semibold text-success" data-testid="text-time-remaining">
                    <Clock className="inline w-4 h-4 mr-1" />
                    {latestKey.timeRemaining?.formatted || '0h 0m'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Key Validation Section */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Validar Chave Existente</h3>
              {validationResult && (
                <Badge className="bg-blue-100 text-blue-800">
                  <Shield className="w-4 h-4 mr-1" />
                  Validação Ativa
                </Badge>
              )}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Input
                type="text"
                placeholder="Cole a chave para validar (ex: KY-2024-ABC123DEF456)"
                value={validationKey}
                onChange={(e) => setValidationKey(e.target.value)}
                className="flex-1 font-mono"
                data-testid="input-validation-key"
              />
              <Button 
                onClick={validateKey}
                className="bg-secondary hover:bg-gray-600 text-white whitespace-nowrap"
                data-testid="button-validate-key"
              >
                <Shield className="w-4 h-4 mr-2" />
                Validar
              </Button>
            </div>

            {validationResult && (
              <div className={`mt-6 border rounded-lg p-6 ${
                validationResult.valid 
                  ? 'bg-green-50 border-green-200' 
                  : 'bg-red-50 border-red-200'
              }`} data-testid="validation-result">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {validationResult.valid ? (
                      <CheckCircle className="text-success text-xl mr-3" />
                    ) : validationResult.status === 'expired' ? (
                      <Clock className="text-warning text-xl mr-3" />
                    ) : (
                      <XCircle className="text-error text-xl mr-3" />
                    )}
                    <div>
                      <div className={`font-bold text-lg ${
                        validationResult.valid ? 'text-success' : 'text-error'
                      }`}>
                        {validationResult.valid ? '✅ Chave Válida' : 
                         validationResult.status === 'expired' ? '⏰ Chave Expirada' : '❌ Chave Inválida'}
                      </div>
                      <div className="text-sm text-gray-600 mt-1">
                        {validationResult.message}
                        {validationResult.valid && validationResult.timeRemaining && 
                          ` - Expira em ${validationResult.timeRemaining.formatted}`}
                      </div>
                    </div>
                  </div>
                  {validationResult.valid && (
                    <div className="text-right">
                      <div className="text-xs text-gray-500 uppercase tracking-wide">Tempo Restante</div>
                      <div className="text-2xl font-bold text-success">
                        {validationResult.timeRemaining?.formatted || '0h 0m'}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Keys History */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Histórico de Chaves</h3>
              <span className="text-sm text-gray-500">Últimas 5 chaves geradas</span>
            </div>

            {keysLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse bg-gray-100 rounded-lg h-16"></div>
                ))}
              </div>
            ) : activeKeys.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Key className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Nenhuma chave ativa no momento</p>
                <p className="text-sm">Gere sua primeira chave usando o botão acima</p>
              </div>
            ) : (
              <div className="space-y-3" data-testid="keys-history">
                {activeKeys.slice(0, 5).map((key) => {
                  const status = getKeyStatus(key);
                  const timeAgo = new Date().getTime() - new Date(key.createdAt).getTime();
                  const hoursAgo = Math.floor(timeAgo / (1000 * 60 * 60));
                  const minutesAgo = Math.floor((timeAgo % (1000 * 60 * 60)) / (1000 * 60));
                  
                  return (
                    <div 
                      key={key.id} 
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                      data-testid={`key-item-${key.id}`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 ${status.color} rounded-full`}></div>
                        <code className="font-mono text-sm bg-white px-2 py-1 rounded">
                          {key.key}
                        </code>
                        <div className="text-sm text-gray-600">
                          {hoursAgo > 0 ? `há ${hoursAgo}h` : `há ${minutesAgo}m`}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={`text-xs text-white px-2 py-1 ${status.color}`}>
                          {key.timeRemaining ? key.timeRemaining.formatted + ' restantes' : 'Expirada'}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(key.key)}
                          data-testid={`button-copy-${key.id}`}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* API Documentation */}
        <Card>
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">API Endpoints</h3>
            
            <div className="space-y-4">
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-2">
                  <Badge className="bg-green-100 text-green-800 font-mono">POST</Badge>
                  <code className="font-mono text-sm">/api/generate</code>
                </div>
                <p className="text-sm text-gray-600">Gera uma nova chave única com expiração de 24 horas</p>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-2">
                  <Badge className="bg-blue-100 text-blue-800 font-mono">GET</Badge>
                  <code className="font-mono text-sm">/api/validate/:key</code>
                </div>
                <p className="text-sm text-gray-600">Valida se uma chave está ativa e não expirou</p>
              </div>

              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center space-x-3 mb-2">
                  <Badge className="bg-blue-100 text-blue-800 font-mono">GET</Badge>
                  <code className="font-mono text-sm">/api/keys</code>
                </div>
                <p className="text-sm text-gray-600">Lista todas as chaves ativas no sistema</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              <Shield className="inline w-4 h-4 mr-1" />
              Sistema de chaves temporárias seguras
            </div>
            <div className="text-sm text-gray-500">
              Powered by Replit
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
