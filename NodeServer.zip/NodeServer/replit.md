# Overview

This is a full-stack web application for generating and validating temporary keys. The system provides a simple interface for creating time-limited access keys (24-hour expiration) and validating their status. Built with a modern React frontend and Express.js backend, it demonstrates a clean separation of concerns with shared TypeScript schemas and a monorepo structure.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI components with Tailwind CSS styling using shadcn/ui design system
- **Build Tool**: Vite with React plugin for fast development and optimized builds

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage Options**: Dual storage implementation - in-memory storage for development and PostgreSQL for production
- **API Design**: RESTful endpoints for key generation (`POST /api/generate`) and validation (`GET /api/validate/:key`)
- **Session Management**: PostgreSQL session store using connect-pg-simple

## Database Schema
- **Keys Table**: Stores generated keys with UUID primary keys, unique key values, creation timestamps, and expiration dates
- **Schema Validation**: Drizzle-Zod integration for runtime type checking and validation
- **Migration System**: Drizzle Kit for database schema migrations

## Key Features
- **Key Generation**: Creates unique alphanumeric keys with format `KY-YYYY-XXXXXXXXXXXX` (12 random characters)
- **Time-based Expiration**: All keys expire 24 hours after creation
- **Real-time Validation**: Live key status checking with remaining time calculations
- **Automatic Cleanup**: Background process removes expired keys every hour

## Development Tools
- **Build System**: ESBuild for production server bundling, Vite for client bundling
- **Type Safety**: Shared TypeScript schemas between client and server via `@shared` alias
- **Code Quality**: Strict TypeScript configuration with comprehensive type checking
- **Development Experience**: Hot module replacement, runtime error overlay, and Replit integration

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting via `@neondatabase/serverless`
- **Drizzle ORM**: Type-safe database toolkit with PostgreSQL dialect support

## UI and Styling
- **Radix UI**: Comprehensive component library for accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **Lucide React**: Modern icon library for consistent iconography

## Development and Build Tools
- **Vite**: Frontend build tool with React support and development server
- **ESBuild**: Fast JavaScript bundler for production server builds
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer plugins

## Utility Libraries
- **TanStack Query**: Server state management and data fetching
- **React Hook Form**: Form state management with Zod schema validation
- **date-fns**: Date manipulation and formatting utilities
- **clsx/twMerge**: Conditional CSS class name utilities

## Development Environment
- **Replit Integration**: Custom plugins for development environment support
- **TypeScript**: Full type safety across the entire application stack