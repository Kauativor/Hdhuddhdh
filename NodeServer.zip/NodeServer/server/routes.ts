import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertKeySchema } from "@shared/schema";
import { z } from "zod";

function generateUniqueKey(): string {
  const year = new Date().getFullYear();
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < 12; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `KY-${year}-${result}`;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Simple test endpoint for Roblox
  app.get("/api/test", (req, res) => {
    res.status(200).json({ 
      success: true, 
      message: "API is working",
      timestamp: new Date().toISOString()
    });
  });

  // Generate a new key
  app.post("/api/generate", async (req, res) => {
    try {
      const keyValue = generateUniqueKey();
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 24); // 24 hours from now

      const keyData = insertKeySchema.parse({
        key: keyValue,
        expiresAt,
      });

      const newKey = await storage.createKey(keyData);
      res.json(newKey);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate key" });
    }
  });

  // Validate a key - Optimized for Roblox
  app.get("/api/validate/:key", async (req, res) => {
    try {
      const { key } = req.params;
      console.log(`[VALIDATION] Checking key: ${key}`);
      
      const keyData = await storage.getKey(key);
      
      if (!keyData) {
        console.log(`[VALIDATION] Key not found: ${key}`);
        return res.status(200).json({ 
          valid: false, 
          status: "invalid",
          message: "Key not found or expired",
          success: false
        });
      }

      const now = new Date();
      const timeRemaining = keyData.expiresAt.getTime() - now.getTime();
      
      if (timeRemaining <= 0) {
        console.log(`[VALIDATION] Key expired: ${key}`);
        return res.status(200).json({ 
          valid: false, 
          status: "expired",
          message: "Key has expired",
          success: false
        });
      }

      const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
      const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));

      console.log(`[VALIDATION] Key valid: ${key}, time remaining: ${hours}h ${minutes}m`);
      
      res.status(200).json({ 
        valid: true, 
        status: "valid",
        message: "Key is valid",
        success: true,
        key: keyData.key,
        timeRemaining: {
          total: timeRemaining,
          hours,
          minutes,
          formatted: `${hours}h ${minutes}m`
        }
      });
    } catch (error) {
      console.error(`[VALIDATION] Error validating key: ${error}`);
      res.status(500).json({ 
        valid: false,
        success: false,
        message: "Failed to validate key" 
      });
    }
  });

  // Get all active keys
  app.get("/api/keys", async (req, res) => {
    try {
      const activeKeys = await storage.getAllActiveKeys();
      
      // Add time remaining for each key
      const keysWithTimeRemaining = activeKeys.map(key => {
        const now = new Date();
        const timeRemaining = key.expiresAt.getTime() - now.getTime();
        const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
        const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
        
        return {
          ...key,
          timeRemaining: {
            total: timeRemaining,
            hours,
            minutes,
            formatted: `${hours}h ${minutes}m`
          }
        };
      });
      
      res.json(keysWithTimeRemaining);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch keys" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
