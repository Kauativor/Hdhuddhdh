import { keys, type Key, type InsertKey } from "@shared/schema";
import { db } from "./db";
import { eq, lt } from "drizzle-orm";

export interface IStorage {
  createKey(key: InsertKey): Promise<Key>;
  getKey(keyValue: string): Promise<Key | undefined>;
  getAllActiveKeys(): Promise<Key[]>;
  deleteExpiredKeys(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Clean up expired keys every hour
    setInterval(() => {
      this.deleteExpiredKeys();
    }, 60 * 60 * 1000);
  }

  async createKey(insertKey: InsertKey): Promise<Key> {
    const [key] = await db
      .insert(keys)
      .values(insertKey)
      .returning();
    return key;
  }

  async getKey(keyValue: string): Promise<Key | undefined> {
    const [key] = await db.select().from(keys).where(eq(keys.key, keyValue));
    
    if (!key) return undefined;
    
    // Check if key is expired
    if (new Date() > key.expiresAt) {
      await db.delete(keys).where(eq(keys.key, keyValue));
      return undefined;
    }
    
    return key;
  }

  async getAllActiveKeys(): Promise<Key[]> {
    const now = new Date();
    
    // First delete expired keys
    await db.delete(keys).where(lt(keys.expiresAt, now));
    
    // Then get all active keys
    const activeKeys = await db.select().from(keys).orderBy(keys.createdAt);
    
    return activeKeys.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async deleteExpiredKeys(): Promise<void> {
    const now = new Date();
    await db.delete(keys).where(lt(keys.expiresAt, now));
  }
}

export const storage = new DatabaseStorage();
